-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2016 at 08:07 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `event_metal`
--

-- --------------------------------------------------------

--
-- Table structure for table `acos`
--

CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `model` varchar(255) NOT NULL,
  `foreign_key` int(11) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `lft` int(11) NOT NULL,
  `rght` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `aros`
--

CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `model` varchar(255) NOT NULL,
  `foreign_key` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `lft` int(11) NOT NULL,
  `rght` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `aros_acos`
--

CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(11) NOT NULL,
  `aro_id` int(11) NOT NULL,
  `aco_id` int(11) NOT NULL,
  `_create` varchar(2) NOT NULL,
  `_read` varchar(2) NOT NULL,
  `_update` varchar(2) NOT NULL,
  `_delete` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(100) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` bigint(20) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL,
  `event_name` varchar(100) NOT NULL,
  `event_desc` text NOT NULL,
  `cat_id` int(11) NOT NULL,
  `start_date_time` datetime NOT NULL,
  `end_date_time` datetime NOT NULL,
  `event_timing` varchar(100) NOT NULL,
  `long_desc` longtext NOT NULL,
  `event_banner` varchar(255) NOT NULL,
  `image_dir` varchar(255) DEFAULT NULL,
  `event_location` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `event_desc`, `cat_id`, `start_date_time`, `end_date_time`, `event_timing`, `long_desc`, `event_banner`, `image_dir`, `event_location`, `created`, `updated`) VALUES
(23, 'jkjlkk', '<p>hkjkjkl</p>\r\n', 6, '2016-02-03 01:00:00', '2016-02-26 01:00:00', '1:00 AM - 1:00 AM', '<p>hkdjfkdsjkfskldfs ll;dl; sadl;ad;l sd;lad;las mdlkamd;las</p>\r\n', 'Hydrangeas.jpg', '94e0c0e1-1ac9-4fb1-8b35-a3a38d178560', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, 'jkjlkk', '<p>hkjkjkl</p>\r\n', 6, '2016-02-03 01:00:00', '2016-02-26 01:00:00', '1:00 AM - 1:00 AM', '<p>kllklkl</p>\r\n', 'Jellyfish.jpg', '205c7033-6519-4a82-a918-5dc6e98ddbe8', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(28, 'Test Events', '<p>hjkhkjhdka akasjkl sdjkajdkl adsj</p>\r\n', 0, '2016-02-01 01:00:00', '2016-02-26 01:00:00', '1:00 AM - 1:00 AM', '<p>jkjjjkkjk;;</p>\r\n', 'Chrysanthemum.jpg', '2440f566-4c40-4c91-a628-b9e98592da4a', 'hjkhkjhdka akasjkl sdjkajdkl adsj', '2016-02-18 19:32:21', '0000-00-00 00:00:00'),
(29, 'qwewqe', '<p>wqewqewq wqewe wqewq qweqwe</p>\r\n', 0, '2016-02-03 00:15:00', '2016-02-25 00:15:00', '12:15 AM - 12:15 AM', '<p>wqewq wewq wewq wqeqwe wqeqw</p>\r\n', 'Koala.jpg', '5ad2e57c-23aa-405d-a9cd-5a731db1f4b0', 'wqewqe wew wqewq', '2016-02-24 18:46:03', '0000-00-00 00:00:00'),
(30, 'tuuii', '<p>fhggfgfg ggyugy uui</p>\r\n', 0, '2016-02-02 00:30:00', '2016-02-25 00:30:00', '12:30 AM - 12:30 AM', '<p>ghuihuhuih huihiu hhkh jnknk jk;k kj</p>\r\n', 'Lighthouse.jpg', 'd7cc01ec-e79a-4edd-9d14-2a8f48812ff7', 'hjhjhjhk hjjhihj hhi', '2016-02-24 18:53:04', '0000-00-00 00:00:00'),
(31, 'tuuii', '<p>fhggfgfg ggyugy uui</p>\r\n', 0, '2016-02-02 00:30:00', '2016-02-25 00:30:00', '12:30 AM - 12:30 AM', '<p>ghuihuhuih huihiu hhkh jnknk jk;k kj</p>\r\n', 'Tulips.jpg', '8582de44-4a10-49c2-8c9f-d18dd90e4fd0', 'hjhjhjhk hjjhihj hhi', '2016-02-26 18:24:22', '0000-00-00 00:00:00'),
(32, 'tuuii', '<p>fhggfgfg ggyugy uui</p>\r\n', 0, '2016-02-02 00:30:00', '2016-02-25 00:30:00', '12:30 AM - 12:30 AM', '<p>ghuihuhuih huihiu hhkh jnknk jk;k kj</p>\r\n', 'Koala.jpg', '925885ef-4666-4935-bc98-2f049ad404a5', 'hjhjhjhk hjjhihj hhi', '2016-02-26 18:28:06', '0000-00-00 00:00:00'),
(33, 'tuuii', '<p>fhggfgfg ggyugy uui</p>\r\n', 0, '2016-02-02 00:30:00', '2016-02-25 00:30:00', '12:30 AM - 12:30 AM', '<p>ghuihuhuih huihiu hhkh jnknk jk;k kj</p>\r\n', 'portrait_Koala.jpg', 'c326f96f-2215-4263-bc0c-967b47ba2748', 'hjhjhjhk hjjhihj hhi', '2016-02-26 18:30:55', '0000-00-00 00:00:00'),
(34, 'tuuii', '<p>fhggfgfg ggyugy uui</p>\r\n', 0, '2016-02-02 00:30:00', '2016-02-25 00:30:00', '12:30 AM - 12:30 AM', '<p>ghuihuhuih huihiu hhkh jnknk jk;k kj</p>\r\n', 'Lighthouse.jpg', 'b555a9cd-5f70-490c-9fc1-1b16d1c01338', 'hjhjhjhk hjjhihj hhi', '2016-02-26 19:50:09', '0000-00-00 00:00:00'),
(35, 'tippp', '<p>lyuiiiiiiiiyuiyuii</p>\r\n', 0, '2016-02-16 01:30:00', '2016-02-29 01:30:00', '1:30 AM - 1:30 AM', '<p><img alt="" src="http://localhost/metal/webroot/imageuploader/uploads/37d5b01.jpg" style="height:160px; width:160px" /></p>\r\n', 'Chrysanthemum.jpg', '83727d58-2940-4b1a-b9aa-b054df2fa64f', 'lklll;l', '2016-02-26 19:54:21', '0000-00-00 00:00:00'),
(36, 'jkjlkk', '<p>hkjkjkl</p>\r\n', 0, '2016-02-03 01:00:00', '2016-02-26 01:00:00', '1:00 AM - 1:00 AM', '<p>hkdjfkdsjkfskldfs ll;dl; sadl;ad;l sd;lad;las mdlkamd;las</p>\r\n', 'Lighthouse.jpg', 'ee85e7cc-2fa7-46c6-af84-347d6a729093', '', '2016-02-28 12:08:54', '0000-00-00 00:00:00'),
(37, 'test event', '<p>test</p>\r\n', 0, '2016-03-16 18:00:00', '2016-03-22 18:00:00', '6:00 PM - 6:00 PM', '<p>fghh</p>\r\n', '12105718_842099015905516_2166035861488622312_n.jpg', 'c09dd2ba-1192-48a3-81f7-583b1f57f34d', 'test', '2016-03-20 12:25:35', '0000-00-00 00:00:00'),
(45, 'Hello Event', '<p>test</p>\r\n', 0, '2016-03-09 02:00:00', '2016-03-16 02:00:00', '2:00 AM - 2:00 AM', '<p>test</p>\r\n', '530774_317794738287860_1146379034_n.jpg', 'ef72eead-9bbb-4448-8733-fbd7d2c2c871', '', '2016-03-26 20:20:30', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `event_speakers`
--

CREATE TABLE IF NOT EXISTS `event_speakers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `full_description` text NOT NULL,
  `event_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `event_speakers`
--

INSERT INTO `event_speakers` (`id`, `user_id`, `full_description`, `event_id`) VALUES
(3, 2, '', 45),
(4, 3, '', 45),
(14, 2, '', 28),
(15, 3, '', 28);

-- --------------------------------------------------------

--
-- Table structure for table `event_sponsers`
--

CREATE TABLE IF NOT EXISTS `event_sponsers` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE IF NOT EXISTS `facilities` (
  `id` int(11) NOT NULL,
  `fc_name` varchar(100) NOT NULL,
  `short_desc` varchar(255) NOT NULL,
  `long_desc` text NOT NULL,
  `event_id` int(11) NOT NULL,
  `fc_image` varchar(255) NOT NULL,
  `image_dir` text
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`id`, `fc_name`, `short_desc`, `long_desc`, `event_id`, `fc_image`, `image_dir`) VALUES
(2, 'Breakfast Included', '<p>Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec t', '<p>Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt</p>\r\n', 28, 'Jellyfish.jpg', 'eb025bde-9183-47c7-9fcd-c536b72a8374'),
(3, 'Parking Available', '<p>Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec t', '<p>Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt Lorem ipsum dolor sit amet, consec tetur adipis icing elit culpa volupt</p>\r\n', 28, 'Tulips.jpg', 'de0fd003-129b-4eae-964e-496ac24f7513');

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE IF NOT EXISTS `friends` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  `status` enum('accepted','pending','decline') NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `created`, `modified`) VALUES
(1, 'admin', '2016-04-06 00:00:00', '0000-00-00 00:00:00'),
(2, 'metal member', '2016-04-06 00:00:00', '0000-00-00 00:00:00'),
(3, 'trial member', '2016-04-06 00:00:00', '0000-00-00 00:00:00'),
(4, 'guest member', '2016-04-06 00:00:00', '0000-00-00 00:00:00'),
(5, 'speaker', '2016-04-06 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `membership`
--

CREATE TABLE IF NOT EXISTS `membership` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `amount` decimal(10,3) NOT NULL,
  `pay_type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `from_id` int(11) NOT NULL,
  `msg` text NOT NULL,
  `created` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` bigint(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `identifier` varchar(100) NOT NULL,
  `content` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `paid_members`
--

CREATE TABLE IF NOT EXISTS `paid_members` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `membership_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_type` varchar(255) NOT NULL,
  `post_content` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `image_dir` varchar(255) NOT NULL,
  `video` varchar(255) NOT NULL,
  `comment_count` int(11) NOT NULL,
  `post_text` varchar(255) NOT NULL,
  `like_count` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `image_caption` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE IF NOT EXISTS `post_likes` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE IF NOT EXISTS `schedules` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `sch_name` varchar(100) NOT NULL,
  `sch_description` text NOT NULL,
  `sch_date` datetime NOT NULL,
  `sch_timing` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `event_id`, `sch_name`, `sch_description`, `sch_date`, `sch_timing`) VALUES
(3, 23, 'kjkljj', '<p>jklj</p>\r\n', '2016-02-18 00:30:00', '12:30 AM'),
(4, 23, 'DAY2', '<p>&lt;div class=&quot;cd-timeline-content bounce-in&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;row equal-height&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;col-sm-8 pr-0 sm-height-auto&quot; style=&quot;min-height: 12.5em;&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;cd-content-left p-15&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;h5 class=&quot;timeline-title&quot;&gt;Speeches/Performances&lt;span class=&quot;toggle-content&quot;&gt;&lt;i class=&quot;fa fa-plus-square-o&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/h5&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;p&gt;Lorem ipsum dolor sit amet, te eum graeco partiendo, ei qui iudico accusamus. Amet rebum nostrud has in, movet iisque no qui, ea duo everti ancillae probatus. Odio ignota vix id. Ex est consul contentiones. Nobis facete usu ut, ludus partem deterruisset ei usu. Vel cu fabulas periculis, eu mea percipit probatus consequuntur.&lt;/p&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;cd-speaker clearfix&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;img width=&quot;70&quot; alt=&quot;&quot; src=&quot;http://localhost/metal/img/front/images/sp-peter-hurley.jpg&quot; class=&quot;pull-left img-circle mr-15&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;h6 class=&quot;pt-0 mb-0&quot;&gt;Peter Hurley&lt;/h6&gt;&lt;span class=&quot;font-12&quot;&gt;Founder - HurleyPro&lt;/span&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;col-sm-4 pl-0 pl-sm-15 sm-height-auto&quot; style=&quot;min-height: 12.5em;&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;cd-content-right p-15&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;ul class=&quot;cd-timeline-meta mt-sm-0&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;li&gt;&lt;i class=&quot;fa fa-clock-o&quot;&gt;&lt;/i&gt; 10 AM - 12:30 AM&lt;/li&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;li&gt;&lt;i class=&quot;fa fa-thumb-tack&quot;&gt;&lt;/i&gt; Crest Westwood, Westwood, CA&lt;/li&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/ul&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;a class=&quot;btn btn-colored btn-theme-colored btn-sm text-uppercase&quot; href=&quot;#&quot;&gt;Read more&lt;/a&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;</p>\r\n', '2016-02-17 00:30:00', '12:30 AM'),
(5, 23, 'DAY4', '<p>&lt;div class=&quot;cd-timeline-content bounce-in&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;row equal-height&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;col-sm-8 pr-0 sm-height-auto&quot; style=&quot;min-height: 12.5em;&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;cd-content-left p-15&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;h5 class=&quot;timeline-title&quot;&gt;Speeches/Performances&lt;span class=&quot;toggle-content&quot;&gt;&lt;i class=&quot;fa fa-plus-square-o&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/h5&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;p&gt;Lorem ipsum dolor sit amet, te eum graeco partiendo, ei qui iudico accusamus. Amet rebum nostrud has in, movet iisque no qui, ea duo everti ancillae probatus. Odio ignota vix id. Ex est consul contentiones. Nobis facete usu ut, ludus partem deterruisset ei usu. Vel cu fabulas periculis, eu mea percipit probatus consequuntur.&lt;/p&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;cd-speaker clearfix&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;img width=&quot;70&quot; alt=&quot;&quot; src=&quot;http://localhost/metal/img/front/images/sp-peter-hurley.jpg&quot; class=&quot;pull-left img-circle mr-15&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;h6 class=&quot;pt-0 mb-0&quot;&gt;Peter Hurley&lt;/h6&gt;&lt;span class=&quot;font-12&quot;&gt;Founder - HurleyPro&lt;/span&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;col-sm-4 pl-0 pl-sm-15 sm-height-auto&quot; style=&quot;min-height: 12.5em;&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;cd-content-right p-15&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;ul class=&quot;cd-timeline-meta mt-sm-0&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;li&gt;&lt;i class=&quot;fa fa-clock-o&quot;&gt;&lt;/i&gt; 10 AM - 12:30 AM&lt;/li&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;li&gt;&lt;i class=&quot;fa fa-thumb-tack&quot;&gt;&lt;/i&gt; Crest Westwood, Westwood, CA&lt;/li&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/ul&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;a class=&quot;btn btn-colored btn-theme-colored btn-sm text-uppercase&quot; href=&quot;#&quot;&gt;Read more&lt;/a&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;</p>\r\n', '2016-02-10 00:30:00', '12:30 AM'),
(6, 23, 'DAT5', '<p>&lt;div class=&quot;cd-timeline-content bounce-in&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;row equal-height&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;col-sm-8 pr-0 sm-height-auto&quot; style=&quot;min-height: 12.5em;&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;cd-content-left p-15&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;h5 class=&quot;timeline-title&quot;&gt;Speeches/Performances&lt;span class=&quot;toggle-content&quot;&gt;&lt;i class=&quot;fa fa-plus-square-o&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/h5&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;p&gt;Lorem ipsum dolor sit amet, te eum graeco partiendo, ei qui iudico accusamus. Amet rebum nostrud has in, movet iisque no qui, ea duo everti ancillae probatus. Odio ignota vix id. Ex est consul contentiones. Nobis facete usu ut, ludus partem deterruisset ei usu. Vel cu fabulas periculis, eu mea percipit probatus consequuntur.&lt;/p&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;cd-speaker clearfix&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;img width=&quot;70&quot; alt=&quot;&quot; src=&quot;http://localhost/metal/img/front/images/sp-peter-hurley.jpg&quot; class=&quot;pull-left img-circle mr-15&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;h6 class=&quot;pt-0 mb-0&quot;&gt;Peter Hurley&lt;/h6&gt;&lt;span class=&quot;font-12&quot;&gt;Founder - HurleyPro&lt;/span&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;col-sm-4 pl-0 pl-sm-15 sm-height-auto&quot; style=&quot;min-height: 12.5em;&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;cd-content-right p-15&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;ul class=&quot;cd-timeline-meta mt-sm-0&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;li&gt;&lt;i class=&quot;fa fa-clock-o&quot;&gt;&lt;/i&gt; 10 AM - 12:30 AM&lt;/li&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;li&gt;&lt;i class=&quot;fa fa-thumb-tack&quot;&gt;&lt;/i&gt; Crest Westwood, Westwood, CA&lt;/li&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/ul&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;a class=&quot;btn btn-colored btn-theme-colored btn-sm text-uppercase&quot; href=&quot;#&quot;&gt;Read more&lt;/a&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;</p>\r\n', '2016-02-17 00:30:00', '12:30 AM'),
(8, 28, 'My Schedule', '<p>test schedule</p>\r\n', '2016-03-08 23:30:00', '11:30 PM'),
(9, 28, 'My Schedule', '<p>test schedule</p>\r\n', '2016-03-08 23:30:00', '11:30 PM'),
(10, 28, 'My Schedule1', '<p>test</p>\r\n', '2016-03-22 23:30:00', '11:30 PM'),
(11, 29, 'My Schedule', '<p>test</p>\r\n', '2016-03-15 23:30:00', '11:30 PM'),
(12, 23, 'My Schedule', '<p>test</p>\r\n', '2016-03-15 23:45:00', '11:45 PM'),
(13, 23, 'My Schedule', '<p>test</p>\r\n', '2016-03-08 23:45:00', '11:45 PM'),
(14, 23, 'My Schedule', '<p>gghghg</p>\r\n', '2016-03-16 00:15:00', '12:15 AM'),
(15, 28, 'My Schedule12', '<p>hjjdk</p>\r\n', '2015-10-07 12:00:00', '12:00 PM');

-- --------------------------------------------------------

--
-- Table structure for table `schedule_tasks`
--

CREATE TABLE IF NOT EXISTS `schedule_tasks` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `schedule_id` int(11) NOT NULL,
  `task_description` longtext NOT NULL,
  `speaker_id` int(11) DEFAULT NULL COMMENT 'user id of speakers role',
  `task_time` varchar(255) DEFAULT NULL,
  `task_location` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `schedule_tasks`
--

INSERT INTO `schedule_tasks` (`id`, `name`, `schedule_id`, `task_description`, `speaker_id`, `task_time`, `task_location`) VALUES
(2, NULL, 1, 'fhgff gygy ggff ', NULL, NULL, NULL),
(3, NULL, 1, 'fhgff gygy ggff ', NULL, NULL, NULL),
(4, NULL, 2, 'fhgff gygy ggff ', NULL, NULL, NULL),
(5, NULL, 2, '<p>&lt;div class=&quot;cd-timeline-content bounce-in&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;row equal-height&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;col-sm-8 pr-0 sm-height-auto&quot; style=&quot;min-height: 12.5em;&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;cd-content-left p-15&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;h5 class=&quot;timeline-title&quot;&gt;Speeches/Performances&lt;span class=&quot;toggle-content&quot;&gt;&lt;i class=&quot;fa fa-plus-square-o&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/h5&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;p&gt;Lorem ipsum dolor sit amet, te eum graeco partiendo, ei qui iudico accusamus. Amet rebum nostrud has in, movet iisque no qui, ea duo everti ancillae probatus. Odio ignota vix id. Ex est consul contentiones. Nobis facete usu ut, ludus partem deterruisset ei usu. Vel cu fabulas periculis, eu mea percipit probatus consequuntur.&lt;/p&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;cd-speaker clearfix&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;img width=&quot;70&quot; alt=&quot;&quot; src=&quot;http://localhost/metal/img/front/images/sp-peter-hurley.jpg&quot; class=&quot;pull-left img-circle mr-15&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;h6 class=&quot;pt-0 mb-0&quot;&gt;Peter Hurley&lt;/h6&gt;&lt;span class=&quot;font-12&quot;&gt;Founder - HurleyPro&lt;/span&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;col-sm-4 pl-0 pl-sm-15 sm-height-auto&quot; style=&quot;min-height: 12.5em;&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;div class=&quot;cd-content-right p-15&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;ul class=&quot;cd-timeline-meta mt-sm-0&quot;&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;li&gt;&lt;i class=&quot;fa fa-clock-o&quot;&gt;&lt;/i&gt; 10 AM - 12:30 AM&lt;/li&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;li&gt;&lt;i class=&quot;fa fa-thumb-tack&quot;&gt;&lt;/i&gt; Crest Westwood, Westwood, CA&lt;/li&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/ul&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;a class=&quot;btn btn-colored btn-theme-colored btn-sm text-uppercase&quot; href=&quot;#&quot;&gt;Read more&lt;/a&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/div&gt;</p>\r\n', NULL, NULL, NULL),
(6, 'test', 14, ' test', 1, '11Am-12Pm', 'test'),
(8, 'test', 14, ' test', 1, '11Am-12Pm', 'test'),
(9, 'test', 14, ' test', 1, '11Am-12Pm', 'test'),
(10, 'test', 14, ' test', 1, '11Am-12Pm', 'test'),
(11, 'my task', 14, ' my task', 1, '11Am-12Pm', 'test'),
(12, 'test', 14, ' ', 1, '11Am-12Pm', 'test'),
(13, 'test', 14, ' dsasd', 1, '11Am-12Pm', 'test'),
(14, 'test', 15, ' sdsfs', 1, '11Am-12Pm', 'test'),
(15, 'test', 15, ' sdsfs', 1, '11Am-12Pm', 'test'),
(16, 'test', 15, ' sdsfstetset', 2, '11Am-12Pm', 'test'),
(17, 'Upcoming', 15, ' test', 3, '11Am-12Pm', 'New York');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `member_price` decimal(10,3) NOT NULL,
  `guest_price` decimal(10,3) NOT NULL,
  `member_desc` text,
  `guest_desc` text
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `event_id`, `member_price`, `guest_price`, `member_desc`, `guest_desc`) VALUES
(2, 28, '20.000', '35.000', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore adipisci, reprehenderit laborum!</p>\r\n', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore adipisci, reprehenderit laborum!</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment_status` varchar(40) NOT NULL,
  `payment_by` varchar(50) NOT NULL,
  `payment_response` text NOT NULL,
  `payment_amount` decimal(10,3) NOT NULL,
  `payment_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `brief_info` text NOT NULL,
  `gender` enum('m','f') DEFAULT NULL,
  `address` text NOT NULL,
  `dob` date NOT NULL,
  `languages` text NOT NULL,
  `profile_status` text NOT NULL,
  `referal` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `company_web` varchar(100) NOT NULL,
  `current_needs` text NOT NULL,
  `position` varchar(100) NOT NULL,
  `industry` varchar(100) NOT NULL,
  `city_town` varchar(100) NOT NULL,
  `zipcode` varchar(50) NOT NULL,
  `state` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `landline` varchar(20) NOT NULL,
  `linkedin_link` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `image` varchar(100) NOT NULL,
  `cover_image` varchar(255) NOT NULL,
  `reset_token` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `image_dir` text,
  `fb_link` varchar(255) DEFAULT NULL,
  `google_plus_link` varchar(255) DEFAULT NULL,
  `twitter_link` varchar(255) DEFAULT NULL,
  `founder` varchar(255) DEFAULT NULL,
  `user_web` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `group_id`, `first_name`, `last_name`, `username`, `email`, `password`, `brief_info`, `gender`, `address`, `dob`, `languages`, `profile_status`, `referal`, `company_name`, `company_web`, `current_needs`, `position`, `industry`, `city_town`, `zipcode`, `state`, `mobile`, `landline`, `linkedin_link`, `created`, `updated`, `image`, `cover_image`, `reset_token`, `active`, `image_dir`, `fb_link`, `google_plus_link`, `twitter_link`, `founder`, `user_web`) VALUES
(1, 1, 'Mohd', 'Ali', 'mohd ali', 'admin@gmail.com', '61cc0e405f4b518d264c089ac8b642ef', '', 'm', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '', 1, NULL, NULL, NULL, NULL, NULL, ''),
(2, 5, 'Test', 'Speaker', '', '', '', '<p>Lorem Ispum&nbsp; Lorem Ispum&nbsp;</p>\r\n', 'm', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2016-03-24 10:57:16', '0000-00-00 00:00:00', '530774_317794738287860_1146379034_n.jpg', '', '', 1, 'c55f5e47-8209-49f3-bd11-bf4949900dd7', 'http://facebook.com/', 'http://google.com/', 'http://twitter.com/', NULL, ''),
(3, 5, 'Event', 'Speaker', '', '', '', '<p>dummy text</p>\r\n', 'm', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2016-03-24 12:55:03', '0000-00-00 00:00:00', '12105718_842099015905516_2166035861488622312_n.jpg', '', '', 1, 'f7d8c3ea-eaef-4e7b-ac74-9fc32a431d75', 'http://facebook.com/', 'http://google.com/', 'http://twitter.com/', NULL, ''),
(5, 3, 'shail', 'kandari', 'shail', 'shail@gmail.com', '$2y$10$0qZ7mW2lQnPeaaQnmCTJs.At2eNM1H/HkpL6grp0ydVBv3McHSZM2', '<p>hellll</p>\r\n', 'm', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '9696969696', '', '', '2016-04-06 19:06:16', '0000-00-00 00:00:00', '', '', '', 1, NULL, '', '', '', NULL, ''),
(6, 2, 'harun', 'ali', 'ali', 'har@ali.com', '123123', 'asdgjsdglhslglskdnglksdjglsd  gklsjd lgs jlg sldgs ldgjlsjd ', 'm', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '1111111112', '', '', '2016-04-07 17:36:45', '0000-00-00 00:00:00', 'Screenshot from 2015-08-14 00:53:22.png', '', '', 1, 'bbde80dd-ad4f-4249-82d2-392011e2c062', '', '', '', NULL, ''),
(9, 0, 'shailendra', 'kandari', 'shailendra_kandari', 'shailendrakandari@gmail.com', '$2y$10$j7nVJmkP7vZ3iMRZQoVOF.lMuLfjl4e4YuOXkT6Q2ePPlNjlWzP0K', 'Hi! My Name is Shailendra kandari, & heres my new user profile page. I love reading people''s about page especially those who are in the same industry as me.', NULL, '8112, W-A, Vele Parley', '2016-04-15', 'English, Russian', 'I won my 2nd Cannabis Cup by taking gourmet candies I discovered at Whole Foods and infusing them our cannabis.', 'Mr. Roscow Duplesis', 'Bizdesire', 'http://www.excellencestar.com', ' We are currently raising our next round of capital for production and operations. We are also looking for high quality content.', 'Creative Director', 'AK', 'San Deigo Bay', '64646', 'MP', '9406517363', '46464646', 'jbk', '2016-04-10 06:04:30', '0000-00-00 00:00:00', 'Image0051.jpg', '', '', 0, NULL, 'https://www.facebook.com/shailendra.kandari', 'nbkj', 'dfh', NULL, 'bjbikb');

-- --------------------------------------------------------

--
-- Table structure for table `users_events`
--

CREATE TABLE IF NOT EXISTS `users_events` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acos`
--
ALTER TABLE `acos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros`
--
ALTER TABLE `aros`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros_acos`
--
ALTER TABLE `aros_acos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_templates`
--
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_speakers`
--
ALTER TABLE `event_speakers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_sponsers`
--
ALTER TABLE `event_sponsers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facilities`
--
ALTER TABLE `facilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `membership`
--
ALTER TABLE `membership`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paid_members`
--
ALTER TABLE `paid_members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule_tasks`
--
ALTER TABLE `schedule_tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_events`
--
ALTER TABLE `users_events`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acos`
--
ALTER TABLE `acos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `aros`
--
ALTER TABLE `aros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `aros_acos`
--
ALTER TABLE `aros_acos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `email_templates`
--
ALTER TABLE `email_templates`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `event_speakers`
--
ALTER TABLE `event_speakers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `event_sponsers`
--
ALTER TABLE `event_sponsers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `facilities`
--
ALTER TABLE `facilities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `membership`
--
ALTER TABLE `membership`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `paid_members`
--
ALTER TABLE `paid_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `schedule_tasks`
--
ALTER TABLE `schedule_tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `users_events`
--
ALTER TABLE `users_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
